import{S as ot,i as $t,s as at,k as T,y as f,a as M,l as U,m as d,z as c,c as C,h as r,n as x,b as B,E as g,A as i,g as p,d as h,B as v,q,r as F,C as I,D as z,F as j,p as ut}from"../chunks/index.c17a76e4.js";import{C as rt}from"../chunks/code.eed80d1b.js";import{E as lt}from"../chunks/example.b3b9ea27.js";import{B as L}from"../chunks/button.9d5c653e.js";import{I as G}from"../chunks/button.5a3614db.js";function ft(a){let t;return{c(){t=q("Button")},l(n){t=F(n,"Button")},m(n,e){B(n,t,e)},d(n){n&&r(t)}}}function ct(a){let t;return{c(){t=q("Button")},l(n){t=F(n,"Button")},m(n,e){B(n,t,e)},d(n){n&&r(t)}}}function it(a){let t;return{c(){t=q("Button")},l(n){t=F(n,"Button")},m(n,e){B(n,t,e)},d(n){n&&r(t)}}}function pt(a){let t;return{c(){t=q("Button")},l(n){t=F(n,"Button")},m(n,e){B(n,t,e)},d(n){n&&r(t)}}}function ht(a){let t;return{c(){t=q("Button")},l(n){t=F(n,"Button")},m(n,e){B(n,t,e)},d(n){n&&r(t)}}}function vt(a){let t;return{c(){t=q("Button")},l(n){t=F(n,"Button")},m(n,e){B(n,t,e)},d(n){n&&r(t)}}}function gt(a){let t;return{c(){t=q("Button")},l(n){t=F(n,"Button")},m(n,e){B(n,t,e)},d(n){n&&r(t)}}}function mt(a){let t;return{c(){t=q("Button")},l(n){t=F(n,"Button")},m(n,e){B(n,t,e)},d(n){n&&r(t)}}}function dt(a){let t;return{c(){t=q("Button")},l(n){t=F(n,"Button")},m(n,e){B(n,t,e)},d(n){n&&r(t)}}}function _t(a){let t;return{c(){t=q("Button")},l(n){t=F(n,"Button")},m(n,e){B(n,t,e)},d(n){n&&r(t)}}}function Bt(a){let t,n,e,s,o,m,_,S,l,W,k,J,b,A,K,P,O,D,Q,N,R,V,H;return e=new L({props:{disableElevation:!0,$$slots:{default:[ft]},$$scope:{ctx:a}}}),o=new L({props:{variant:"tonal",$$slots:{default:[ct]},$$scope:{ctx:a}}}),_=new L({props:{variant:"elevated",$$slots:{default:[it]},$$scope:{ctx:a}}}),l=new L({props:{variant:"outline",$$slots:{default:[pt]},$$scope:{ctx:a}}}),k=new L({props:{variant:"text",$$slots:{default:[ht]},$$scope:{ctx:a}}}),A=new L({props:{disabled:!0,$$slots:{default:[vt]},$$scope:{ctx:a}}}),P=new L({props:{disabled:!0,variant:"tonal",$$slots:{default:[gt]},$$scope:{ctx:a}}}),D=new L({props:{disabled:!0,variant:"elevated",$$slots:{default:[mt]},$$scope:{ctx:a}}}),N=new L({props:{disabled:!0,variant:"outline",$$slots:{default:[dt]},$$scope:{ctx:a}}}),V=new L({props:{disabled:!0,variant:"text",$$slots:{default:[_t]},$$scope:{ctx:a}}}),{c(){t=T("div"),n=T("span"),f(e.$$.fragment),s=M(),f(o.$$.fragment),m=M(),f(_.$$.fragment),S=M(),f(l.$$.fragment),W=M(),f(k.$$.fragment),J=M(),b=T("span"),f(A.$$.fragment),K=M(),f(P.$$.fragment),O=M(),f(D.$$.fragment),Q=M(),f(N.$$.fragment),R=M(),f(V.$$.fragment),this.h()},l($){t=U($,"DIV",{});var u=d(t);n=U(u,"SPAN",{class:!0});var w=d(n);c(e.$$.fragment,w),s=C(w),c(o.$$.fragment,w),m=C(w),c(_.$$.fragment,w),S=C(w),c(l.$$.fragment,w),W=C(w),c(k.$$.fragment,w),w.forEach(r),J=C(u),b=U(u,"SPAN",{class:!0});var E=d(b);c(A.$$.fragment,E),K=C(E),c(P.$$.fragment,E),O=C(E),c(D.$$.fragment,E),Q=C(E),c(N.$$.fragment,E),R=C(E),c(V.$$.fragment,E),E.forEach(r),u.forEach(r),this.h()},h(){x(n,"class","svelte-1ect03w"),x(b,"class","svelte-1ect03w")},m($,u){B($,t,u),g(t,n),i(e,n,null),g(n,s),i(o,n,null),g(n,m),i(_,n,null),g(n,S),i(l,n,null),g(n,W),i(k,n,null),g(t,J),g(t,b),i(A,b,null),g(b,K),i(P,b,null),g(b,O),i(D,b,null),g(b,Q),i(N,b,null),g(b,R),i(V,b,null),H=!0},p($,[u]){const w={};u&1&&(w.$$scope={dirty:u,ctx:$}),e.$set(w);const E={};u&1&&(E.$$scope={dirty:u,ctx:$}),o.$set(E);const X={};u&1&&(X.$$scope={dirty:u,ctx:$}),_.$set(X);const Y={};u&1&&(Y.$$scope={dirty:u,ctx:$}),l.$set(Y);const Z={};u&1&&(Z.$$scope={dirty:u,ctx:$}),k.$set(Z);const y={};u&1&&(y.$$scope={dirty:u,ctx:$}),A.$set(y);const tt={};u&1&&(tt.$$scope={dirty:u,ctx:$}),P.$set(tt);const et={};u&1&&(et.$$scope={dirty:u,ctx:$}),D.$set(et);const nt={};u&1&&(nt.$$scope={dirty:u,ctx:$}),N.$set(nt);const st={};u&1&&(st.$$scope={dirty:u,ctx:$}),V.$set(st)},i($){H||(p(e.$$.fragment,$),p(o.$$.fragment,$),p(_.$$.fragment,$),p(l.$$.fragment,$),p(k.$$.fragment,$),p(A.$$.fragment,$),p(P.$$.fragment,$),p(D.$$.fragment,$),p(N.$$.fragment,$),p(V.$$.fragment,$),H=!0)},o($){h(e.$$.fragment,$),h(o.$$.fragment,$),h(_.$$.fragment,$),h(l.$$.fragment,$),h(k.$$.fragment,$),h(A.$$.fragment,$),h(P.$$.fragment,$),h(D.$$.fragment,$),h(N.$$.fragment,$),h(V.$$.fragment,$),H=!1},d($){$&&r(t),v(e),v(o),v(_),v(l),v(k),v(A),v(P),v(D),v(N),v(V)}}}class bt extends ot{constructor(t){super(),$t(this,t,null,Bt,at,{})}}const wt=`<script>
	import Button from '@mui3/button';
<\/script>

<div>
	<span>
		<Button disableElevation>Button</Button>
		<Button variant="tonal">Button</Button>
		<Button variant="elevated">Button</Button>
		<Button variant="outline">Button</Button>
		<Button variant="text">Button</Button>
	</span>

	<span>
		<Button disabled>Button</Button>
		<Button disabled variant="tonal">Button</Button>
		<Button disabled variant="elevated">Button</Button>
		<Button disabled variant="outline">Button</Button>
		<Button disabled variant="text">Button</Button>
	</span>
</div>

<style>
	span {
		display: flex;
		flex-wrap: wrap;
		gap: 16px;
		padding: 8px 0;
	}
</style>
`;function Et(a){let t,n;return{c(){t=I("svg"),n=I("path"),this.h()},l(e){t=z(e,"svg",{viewBox:!0});var s=d(t);n=z(s,"path",{d:!0}),d(n).forEach(r),s.forEach(r),this.h()},h(){x(n,"d","M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"),x(t,"viewBox","0 0 24 24")},m(e,s){B(e,t,s),g(t,n)},p:j,d(e){e&&r(t)}}}function It(a){let t,n,e;return t=new G({props:{small:!0,$$slots:{default:[Et]},$$scope:{ctx:a}}}),{c(){f(t.$$.fragment),n=q(`
			Button`)},l(s){c(t.$$.fragment,s),n=F(s,`
			Button`)},m(s,o){i(t,s,o),B(s,n,o),e=!0},p(s,o){const m={};o&1&&(m.$$scope={dirty:o,ctx:s}),t.$set(m)},i(s){e||(p(t.$$.fragment,s),e=!0)},o(s){h(t.$$.fragment,s),e=!1},d(s){v(t,s),s&&r(n)}}}function zt(a){let t,n;return{c(){t=I("svg"),n=I("path"),this.h()},l(e){t=z(e,"svg",{viewBox:!0});var s=d(t);n=z(s,"path",{d:!0}),d(n).forEach(r),s.forEach(r),this.h()},h(){x(n,"d","M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"),x(t,"viewBox","0 0 24 24")},m(e,s){B(e,t,s),g(t,n)},p:j,d(e){e&&r(t)}}}function xt(a){let t,n,e;return t=new G({props:{small:!0,$$slots:{default:[zt]},$$scope:{ctx:a}}}),{c(){f(t.$$.fragment),n=q(`
			Button`)},l(s){c(t.$$.fragment,s),n=F(s,`
			Button`)},m(s,o){i(t,s,o),B(s,n,o),e=!0},p(s,o){const m={};o&1&&(m.$$scope={dirty:o,ctx:s}),t.$set(m)},i(s){e||(p(t.$$.fragment,s),e=!0)},o(s){h(t.$$.fragment,s),e=!1},d(s){v(t,s),s&&r(n)}}}function Lt(a){let t,n;return{c(){t=I("svg"),n=I("path"),this.h()},l(e){t=z(e,"svg",{viewBox:!0});var s=d(t);n=z(s,"path",{d:!0}),d(n).forEach(r),s.forEach(r),this.h()},h(){x(n,"d","M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"),x(t,"viewBox","0 0 24 24")},m(e,s){B(e,t,s),g(t,n)},p:j,d(e){e&&r(t)}}}function Mt(a){let t,n,e;return t=new G({props:{small:!0,$$slots:{default:[Lt]},$$scope:{ctx:a}}}),{c(){f(t.$$.fragment),n=q(`
			Button`)},l(s){c(t.$$.fragment,s),n=F(s,`
			Button`)},m(s,o){i(t,s,o),B(s,n,o),e=!0},p(s,o){const m={};o&1&&(m.$$scope={dirty:o,ctx:s}),t.$set(m)},i(s){e||(p(t.$$.fragment,s),e=!0)},o(s){h(t.$$.fragment,s),e=!1},d(s){v(t,s),s&&r(n)}}}function Ct(a){let t,n;return{c(){t=I("svg"),n=I("path"),this.h()},l(e){t=z(e,"svg",{viewBox:!0});var s=d(t);n=z(s,"path",{d:!0}),d(n).forEach(r),s.forEach(r),this.h()},h(){x(n,"d","M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"),x(t,"viewBox","0 0 24 24")},m(e,s){B(e,t,s),g(t,n)},p:j,d(e){e&&r(t)}}}function St(a){let t,n,e;return t=new G({props:{small:!0,$$slots:{default:[Ct]},$$scope:{ctx:a}}}),{c(){f(t.$$.fragment),n=q(`
			Button`)},l(s){c(t.$$.fragment,s),n=F(s,`
			Button`)},m(s,o){i(t,s,o),B(s,n,o),e=!0},p(s,o){const m={};o&1&&(m.$$scope={dirty:o,ctx:s}),t.$set(m)},i(s){e||(p(t.$$.fragment,s),e=!0)},o(s){h(t.$$.fragment,s),e=!1},d(s){v(t,s),s&&r(n)}}}function kt(a){let t,n;return{c(){t=I("svg"),n=I("path"),this.h()},l(e){t=z(e,"svg",{viewBox:!0});var s=d(t);n=z(s,"path",{d:!0}),d(n).forEach(r),s.forEach(r),this.h()},h(){x(n,"d","M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"),x(t,"viewBox","0 0 24 24")},m(e,s){B(e,t,s),g(t,n)},p:j,d(e){e&&r(t)}}}function At(a){let t,n,e;return t=new G({props:{small:!0,$$slots:{default:[kt]},$$scope:{ctx:a}}}),{c(){f(t.$$.fragment),n=q(`
			Button`)},l(s){c(t.$$.fragment,s),n=F(s,`
			Button`)},m(s,o){i(t,s,o),B(s,n,o),e=!0},p(s,o){const m={};o&1&&(m.$$scope={dirty:o,ctx:s}),t.$set(m)},i(s){e||(p(t.$$.fragment,s),e=!0)},o(s){h(t.$$.fragment,s),e=!1},d(s){v(t,s),s&&r(n)}}}function Pt(a){let t,n;return{c(){t=I("svg"),n=I("path"),this.h()},l(e){t=z(e,"svg",{viewBox:!0});var s=d(t);n=z(s,"path",{d:!0}),d(n).forEach(r),s.forEach(r),this.h()},h(){x(n,"d","M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"),x(t,"viewBox","0 0 24 24")},m(e,s){B(e,t,s),g(t,n)},p:j,d(e){e&&r(t)}}}function Dt(a){let t,n,e;return t=new G({props:{small:!0,$$slots:{default:[Pt]},$$scope:{ctx:a}}}),{c(){f(t.$$.fragment),n=q(`
			Button`)},l(s){c(t.$$.fragment,s),n=F(s,`
			Button`)},m(s,o){i(t,s,o),B(s,n,o),e=!0},p(s,o){const m={};o&1&&(m.$$scope={dirty:o,ctx:s}),t.$set(m)},i(s){e||(p(t.$$.fragment,s),e=!0)},o(s){h(t.$$.fragment,s),e=!1},d(s){v(t,s),s&&r(n)}}}function Nt(a){let t,n;return{c(){t=I("svg"),n=I("path"),this.h()},l(e){t=z(e,"svg",{viewBox:!0});var s=d(t);n=z(s,"path",{d:!0}),d(n).forEach(r),s.forEach(r),this.h()},h(){x(n,"d","M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"),x(t,"viewBox","0 0 24 24")},m(e,s){B(e,t,s),g(t,n)},p:j,d(e){e&&r(t)}}}function Vt(a){let t,n,e;return t=new G({props:{small:!0,$$slots:{default:[Nt]},$$scope:{ctx:a}}}),{c(){f(t.$$.fragment),n=q(`
			Button`)},l(s){c(t.$$.fragment,s),n=F(s,`
			Button`)},m(s,o){i(t,s,o),B(s,n,o),e=!0},p(s,o){const m={};o&1&&(m.$$scope={dirty:o,ctx:s}),t.$set(m)},i(s){e||(p(t.$$.fragment,s),e=!0)},o(s){h(t.$$.fragment,s),e=!1},d(s){v(t,s),s&&r(n)}}}function Wt(a){let t,n;return{c(){t=I("svg"),n=I("path"),this.h()},l(e){t=z(e,"svg",{viewBox:!0});var s=d(t);n=z(s,"path",{d:!0}),d(n).forEach(r),s.forEach(r),this.h()},h(){x(n,"d","M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"),x(t,"viewBox","0 0 24 24")},m(e,s){B(e,t,s),g(t,n)},p:j,d(e){e&&r(t)}}}function qt(a){let t,n,e;return t=new G({props:{small:!0,$$slots:{default:[Wt]},$$scope:{ctx:a}}}),{c(){f(t.$$.fragment),n=q(`
			Button`)},l(s){c(t.$$.fragment,s),n=F(s,`
			Button`)},m(s,o){i(t,s,o),B(s,n,o),e=!0},p(s,o){const m={};o&1&&(m.$$scope={dirty:o,ctx:s}),t.$set(m)},i(s){e||(p(t.$$.fragment,s),e=!0)},o(s){h(t.$$.fragment,s),e=!1},d(s){v(t,s),s&&r(n)}}}function Ft(a){let t,n;return{c(){t=I("svg"),n=I("path"),this.h()},l(e){t=z(e,"svg",{viewBox:!0});var s=d(t);n=z(s,"path",{d:!0}),d(n).forEach(r),s.forEach(r),this.h()},h(){x(n,"d","M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"),x(t,"viewBox","0 0 24 24")},m(e,s){B(e,t,s),g(t,n)},p:j,d(e){e&&r(t)}}}function jt(a){let t,n,e;return t=new G({props:{small:!0,$$slots:{default:[Ft]},$$scope:{ctx:a}}}),{c(){f(t.$$.fragment),n=q(`
			Button`)},l(s){c(t.$$.fragment,s),n=F(s,`
			Button`)},m(s,o){i(t,s,o),B(s,n,o),e=!0},p(s,o){const m={};o&1&&(m.$$scope={dirty:o,ctx:s}),t.$set(m)},i(s){e||(p(t.$$.fragment,s),e=!0)},o(s){h(t.$$.fragment,s),e=!1},d(s){v(t,s),s&&r(n)}}}function Gt(a){let t,n;return{c(){t=I("svg"),n=I("path"),this.h()},l(e){t=z(e,"svg",{viewBox:!0});var s=d(t);n=z(s,"path",{d:!0}),d(n).forEach(r),s.forEach(r),this.h()},h(){x(n,"d","M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"),x(t,"viewBox","0 0 24 24")},m(e,s){B(e,t,s),g(t,n)},p:j,d(e){e&&r(t)}}}function Ht(a){let t,n,e;return t=new G({props:{small:!0,$$slots:{default:[Gt]},$$scope:{ctx:a}}}),{c(){f(t.$$.fragment),n=q(`
			Button`)},l(s){c(t.$$.fragment,s),n=F(s,`
			Button`)},m(s,o){i(t,s,o),B(s,n,o),e=!0},p(s,o){const m={};o&1&&(m.$$scope={dirty:o,ctx:s}),t.$set(m)},i(s){e||(p(t.$$.fragment,s),e=!0)},o(s){h(t.$$.fragment,s),e=!1},d(s){v(t,s),s&&r(n)}}}function Jt(a){let t,n,e,s,o,m,_,S,l,W,k,J,b,A,K,P,O,D,Q,N,R,V,H;return e=new L({props:{$$slots:{default:[It]},$$scope:{ctx:a}}}),o=new L({props:{variant:"tonal",$$slots:{default:[xt]},$$scope:{ctx:a}}}),_=new L({props:{variant:"elevated",$$slots:{default:[Mt]},$$scope:{ctx:a}}}),l=new L({props:{variant:"outline",$$slots:{default:[St]},$$scope:{ctx:a}}}),k=new L({props:{variant:"text",$$slots:{default:[At]},$$scope:{ctx:a}}}),A=new L({props:{disabled:!0,$$slots:{default:[Dt]},$$scope:{ctx:a}}}),P=new L({props:{disabled:!0,variant:"tonal",$$slots:{default:[Vt]},$$scope:{ctx:a}}}),D=new L({props:{disabled:!0,variant:"elevated",$$slots:{default:[qt]},$$scope:{ctx:a}}}),N=new L({props:{disabled:!0,variant:"outline",$$slots:{default:[jt]},$$scope:{ctx:a}}}),V=new L({props:{disabled:!0,variant:"text",$$slots:{default:[Ht]},$$scope:{ctx:a}}}),{c(){t=T("div"),n=T("span"),f(e.$$.fragment),s=M(),f(o.$$.fragment),m=M(),f(_.$$.fragment),S=M(),f(l.$$.fragment),W=M(),f(k.$$.fragment),J=M(),b=T("span"),f(A.$$.fragment),K=M(),f(P.$$.fragment),O=M(),f(D.$$.fragment),Q=M(),f(N.$$.fragment),R=M(),f(V.$$.fragment),this.h()},l($){t=U($,"DIV",{});var u=d(t);n=U(u,"SPAN",{class:!0});var w=d(n);c(e.$$.fragment,w),s=C(w),c(o.$$.fragment,w),m=C(w),c(_.$$.fragment,w),S=C(w),c(l.$$.fragment,w),W=C(w),c(k.$$.fragment,w),w.forEach(r),J=C(u),b=U(u,"SPAN",{class:!0});var E=d(b);c(A.$$.fragment,E),K=C(E),c(P.$$.fragment,E),O=C(E),c(D.$$.fragment,E),Q=C(E),c(N.$$.fragment,E),R=C(E),c(V.$$.fragment,E),E.forEach(r),u.forEach(r),this.h()},h(){x(n,"class","svelte-1ect03w"),x(b,"class","svelte-1ect03w")},m($,u){B($,t,u),g(t,n),i(e,n,null),g(n,s),i(o,n,null),g(n,m),i(_,n,null),g(n,S),i(l,n,null),g(n,W),i(k,n,null),g(t,J),g(t,b),i(A,b,null),g(b,K),i(P,b,null),g(b,O),i(D,b,null),g(b,Q),i(N,b,null),g(b,R),i(V,b,null),H=!0},p($,[u]){const w={};u&1&&(w.$$scope={dirty:u,ctx:$}),e.$set(w);const E={};u&1&&(E.$$scope={dirty:u,ctx:$}),o.$set(E);const X={};u&1&&(X.$$scope={dirty:u,ctx:$}),_.$set(X);const Y={};u&1&&(Y.$$scope={dirty:u,ctx:$}),l.$set(Y);const Z={};u&1&&(Z.$$scope={dirty:u,ctx:$}),k.$set(Z);const y={};u&1&&(y.$$scope={dirty:u,ctx:$}),A.$set(y);const tt={};u&1&&(tt.$$scope={dirty:u,ctx:$}),P.$set(tt);const et={};u&1&&(et.$$scope={dirty:u,ctx:$}),D.$set(et);const nt={};u&1&&(nt.$$scope={dirty:u,ctx:$}),N.$set(nt);const st={};u&1&&(st.$$scope={dirty:u,ctx:$}),V.$set(st)},i($){H||(p(e.$$.fragment,$),p(o.$$.fragment,$),p(_.$$.fragment,$),p(l.$$.fragment,$),p(k.$$.fragment,$),p(A.$$.fragment,$),p(P.$$.fragment,$),p(D.$$.fragment,$),p(N.$$.fragment,$),p(V.$$.fragment,$),H=!0)},o($){h(e.$$.fragment,$),h(o.$$.fragment,$),h(_.$$.fragment,$),h(l.$$.fragment,$),h(k.$$.fragment,$),h(A.$$.fragment,$),h(P.$$.fragment,$),h(D.$$.fragment,$),h(N.$$.fragment,$),h(V.$$.fragment,$),H=!1},d($){$&&r(t),v(e),v(o),v(_),v(l),v(k),v(A),v(P),v(D),v(N),v(V)}}}class Kt extends ot{constructor(t){super(),$t(this,t,null,Jt,at,{})}}const Ot=`<script>
	import Button from '@mui3/button';
	import Icon from '@mui3/icon';
<\/script>
<div>
	<span>
		<Button>
			<Icon small>
				<svg viewBox="0 0 24 24">
					<path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
				</svg>
			</Icon>
			Button
		</Button>
		<Button variant="tonal">
			<Icon small>
				<svg viewBox="0 0 24 24">
					<path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
				</svg>
			</Icon>
			Button
		</Button>
		<Button variant="elevated">
			<Icon small>
				<svg viewBox="0 0 24 24">
					<path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
				</svg>
			</Icon>
			Button
		</Button>
		<Button variant="outline">
			<Icon small>
				<svg viewBox="0 0 24 24">
					<path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
				</svg>
			</Icon>
			Button
		</Button>
		<Button variant="text">
			<Icon small>
				<svg viewBox="0 0 24 24">
					<path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
				</svg>
			</Icon>
			Button
		</Button>
	</span>
	<span>
		<Button disabled>
			<Icon small>
				<svg viewBox="0 0 24 24">
					<path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
				</svg>
			</Icon>
			Button
		</Button>
		<Button disabled variant="tonal">
			<Icon small>
				<svg viewBox="0 0 24 24">
					<path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
				</svg>
			</Icon>
			Button
		</Button>
		<Button disabled variant="elevated">
			<Icon small>
				<svg viewBox="0 0 24 24">
					<path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
				</svg>
			</Icon>
			Button
		</Button>
		<Button disabled variant="outline">
			<Icon small>
				<svg viewBox="0 0 24 24">
					<path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
				</svg>
			</Icon>
			Button
		</Button>
		<Button disabled variant="text">
			<Icon small>
				<svg viewBox="0 0 24 24">
					<path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
				</svg>
			</Icon>
			Button
		</Button>
	</span>
</div>
<style>
	span {
		display: flex;
		flex-wrap: wrap;
		gap: 16px;
		padding: 8px 0;
	}
</style>
`;function Qt(a){let t,n;return{c(){t=I("svg"),n=I("path"),this.h()},l(e){t=z(e,"svg",{});var s=d(t);n=z(s,"path",{d:!0}),d(n).forEach(r),s.forEach(r),this.h()},h(){x(n,"d","M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z")},m(e,s){B(e,t,s),g(t,n)},p:j,d(e){e&&r(t)}}}function Rt(a){let t,n;return t=new G({props:{$$slots:{default:[Qt]},$$scope:{ctx:a}}}),{c(){f(t.$$.fragment)},l(e){c(t.$$.fragment,e)},m(e,s){i(t,e,s),n=!0},p(e,s){const o={};s&1&&(o.$$scope={dirty:s,ctx:e}),t.$set(o)},i(e){n||(p(t.$$.fragment,e),n=!0)},o(e){h(t.$$.fragment,e),n=!1},d(e){v(t,e)}}}function Tt(a){let t,n;return{c(){t=I("svg"),n=I("path"),this.h()},l(e){t=z(e,"svg",{});var s=d(t);n=z(s,"path",{d:!0}),d(n).forEach(r),s.forEach(r),this.h()},h(){x(n,"d","M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z")},m(e,s){B(e,t,s),g(t,n)},p:j,d(e){e&&r(t)}}}function Ut(a){let t,n;return t=new G({props:{$$slots:{default:[Tt]},$$scope:{ctx:a}}}),{c(){f(t.$$.fragment)},l(e){c(t.$$.fragment,e)},m(e,s){i(t,e,s),n=!0},p(e,s){const o={};s&1&&(o.$$scope={dirty:s,ctx:e}),t.$set(o)},i(e){n||(p(t.$$.fragment,e),n=!0)},o(e){h(t.$$.fragment,e),n=!1},d(e){v(t,e)}}}function Xt(a){let t,n;return{c(){t=I("svg"),n=I("path"),this.h()},l(e){t=z(e,"svg",{});var s=d(t);n=z(s,"path",{d:!0}),d(n).forEach(r),s.forEach(r),this.h()},h(){x(n,"d","M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z")},m(e,s){B(e,t,s),g(t,n)},p:j,d(e){e&&r(t)}}}function Yt(a){let t,n;return t=new G({props:{$$slots:{default:[Xt]},$$scope:{ctx:a}}}),{c(){f(t.$$.fragment)},l(e){c(t.$$.fragment,e)},m(e,s){i(t,e,s),n=!0},p(e,s){const o={};s&1&&(o.$$scope={dirty:s,ctx:e}),t.$set(o)},i(e){n||(p(t.$$.fragment,e),n=!0)},o(e){h(t.$$.fragment,e),n=!1},d(e){v(t,e)}}}function Zt(a){let t,n;return{c(){t=I("svg"),n=I("path"),this.h()},l(e){t=z(e,"svg",{});var s=d(t);n=z(s,"path",{d:!0}),d(n).forEach(r),s.forEach(r),this.h()},h(){x(n,"d","M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z")},m(e,s){B(e,t,s),g(t,n)},p:j,d(e){e&&r(t)}}}function yt(a){let t,n;return t=new G({props:{$$slots:{default:[Zt]},$$scope:{ctx:a}}}),{c(){f(t.$$.fragment)},l(e){c(t.$$.fragment,e)},m(e,s){i(t,e,s),n=!0},p(e,s){const o={};s&1&&(o.$$scope={dirty:s,ctx:e}),t.$set(o)},i(e){n||(p(t.$$.fragment,e),n=!0)},o(e){h(t.$$.fragment,e),n=!1},d(e){v(t,e)}}}function te(a){let t,n;return{c(){t=I("svg"),n=I("path"),this.h()},l(e){t=z(e,"svg",{});var s=d(t);n=z(s,"path",{d:!0}),d(n).forEach(r),s.forEach(r),this.h()},h(){x(n,"d","M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z")},m(e,s){B(e,t,s),g(t,n)},p:j,d(e){e&&r(t)}}}function ee(a){let t,n;return t=new G({props:{$$slots:{default:[te]},$$scope:{ctx:a}}}),{c(){f(t.$$.fragment)},l(e){c(t.$$.fragment,e)},m(e,s){i(t,e,s),n=!0},p(e,s){const o={};s&1&&(o.$$scope={dirty:s,ctx:e}),t.$set(o)},i(e){n||(p(t.$$.fragment,e),n=!0)},o(e){h(t.$$.fragment,e),n=!1},d(e){v(t,e)}}}function ne(a){let t,n;return{c(){t=I("svg"),n=I("path"),this.h()},l(e){t=z(e,"svg",{});var s=d(t);n=z(s,"path",{d:!0}),d(n).forEach(r),s.forEach(r),this.h()},h(){x(n,"d","M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z")},m(e,s){B(e,t,s),g(t,n)},p:j,d(e){e&&r(t)}}}function se(a){let t,n;return t=new G({props:{$$slots:{default:[ne]},$$scope:{ctx:a}}}),{c(){f(t.$$.fragment)},l(e){c(t.$$.fragment,e)},m(e,s){i(t,e,s),n=!0},p(e,s){const o={};s&1&&(o.$$scope={dirty:s,ctx:e}),t.$set(o)},i(e){n||(p(t.$$.fragment,e),n=!0)},o(e){h(t.$$.fragment,e),n=!1},d(e){v(t,e)}}}function oe(a){let t,n;return{c(){t=I("svg"),n=I("path"),this.h()},l(e){t=z(e,"svg",{});var s=d(t);n=z(s,"path",{d:!0}),d(n).forEach(r),s.forEach(r),this.h()},h(){x(n,"d","M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z")},m(e,s){B(e,t,s),g(t,n)},p:j,d(e){e&&r(t)}}}function $e(a){let t,n;return t=new G({props:{$$slots:{default:[oe]},$$scope:{ctx:a}}}),{c(){f(t.$$.fragment)},l(e){c(t.$$.fragment,e)},m(e,s){i(t,e,s),n=!0},p(e,s){const o={};s&1&&(o.$$scope={dirty:s,ctx:e}),t.$set(o)},i(e){n||(p(t.$$.fragment,e),n=!0)},o(e){h(t.$$.fragment,e),n=!1},d(e){v(t,e)}}}function ae(a){let t,n;return{c(){t=I("svg"),n=I("path"),this.h()},l(e){t=z(e,"svg",{});var s=d(t);n=z(s,"path",{d:!0}),d(n).forEach(r),s.forEach(r),this.h()},h(){x(n,"d","M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z")},m(e,s){B(e,t,s),g(t,n)},p:j,d(e){e&&r(t)}}}function re(a){let t,n;return t=new G({props:{$$slots:{default:[ae]},$$scope:{ctx:a}}}),{c(){f(t.$$.fragment)},l(e){c(t.$$.fragment,e)},m(e,s){i(t,e,s),n=!0},p(e,s){const o={};s&1&&(o.$$scope={dirty:s,ctx:e}),t.$set(o)},i(e){n||(p(t.$$.fragment,e),n=!0)},o(e){h(t.$$.fragment,e),n=!1},d(e){v(t,e)}}}function ue(a){let t,n;return{c(){t=I("svg"),n=I("path"),this.h()},l(e){t=z(e,"svg",{});var s=d(t);n=z(s,"path",{d:!0}),d(n).forEach(r),s.forEach(r),this.h()},h(){x(n,"d","M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z")},m(e,s){B(e,t,s),g(t,n)},p:j,d(e){e&&r(t)}}}function le(a){let t,n;return t=new G({props:{$$slots:{default:[ue]},$$scope:{ctx:a}}}),{c(){f(t.$$.fragment)},l(e){c(t.$$.fragment,e)},m(e,s){i(t,e,s),n=!0},p(e,s){const o={};s&1&&(o.$$scope={dirty:s,ctx:e}),t.$set(o)},i(e){n||(p(t.$$.fragment,e),n=!0)},o(e){h(t.$$.fragment,e),n=!1},d(e){v(t,e)}}}function fe(a){let t,n;return{c(){t=I("svg"),n=I("path"),this.h()},l(e){t=z(e,"svg",{});var s=d(t);n=z(s,"path",{d:!0}),d(n).forEach(r),s.forEach(r),this.h()},h(){x(n,"d","M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z")},m(e,s){B(e,t,s),g(t,n)},p:j,d(e){e&&r(t)}}}function ce(a){let t,n;return t=new G({props:{$$slots:{default:[fe]},$$scope:{ctx:a}}}),{c(){f(t.$$.fragment)},l(e){c(t.$$.fragment,e)},m(e,s){i(t,e,s),n=!0},p(e,s){const o={};s&1&&(o.$$scope={dirty:s,ctx:e}),t.$set(o)},i(e){n||(p(t.$$.fragment,e),n=!0)},o(e){h(t.$$.fragment,e),n=!1},d(e){v(t,e)}}}function ie(a){let t,n,e,s,o,m,_,S,l,W,k,J,b,A,K,P,O,D,Q,N,R,V,H;return e=new L({props:{icon:!0,$$slots:{default:[Rt]},$$scope:{ctx:a}}}),o=new L({props:{icon:!0,variant:"tonal",$$slots:{default:[Ut]},$$scope:{ctx:a}}}),_=new L({props:{icon:!0,variant:"elevated",$$slots:{default:[Yt]},$$scope:{ctx:a}}}),l=new L({props:{icon:!0,variant:"outline",$$slots:{default:[yt]},$$scope:{ctx:a}}}),k=new L({props:{icon:!0,variant:"text",$$slots:{default:[ee]},$$scope:{ctx:a}}}),A=new L({props:{disabled:!0,icon:!0,$$slots:{default:[se]},$$scope:{ctx:a}}}),P=new L({props:{disabled:!0,icon:!0,variant:"tonal",$$slots:{default:[$e]},$$scope:{ctx:a}}}),D=new L({props:{disabled:!0,icon:!0,variant:"elevated",$$slots:{default:[re]},$$scope:{ctx:a}}}),N=new L({props:{disabled:!0,icon:!0,variant:"outline",$$slots:{default:[le]},$$scope:{ctx:a}}}),V=new L({props:{disabled:!0,icon:!0,variant:"text",$$slots:{default:[ce]},$$scope:{ctx:a}}}),{c(){t=T("div"),n=T("span"),f(e.$$.fragment),s=M(),f(o.$$.fragment),m=M(),f(_.$$.fragment),S=M(),f(l.$$.fragment),W=M(),f(k.$$.fragment),J=M(),b=T("span"),f(A.$$.fragment),K=M(),f(P.$$.fragment),O=M(),f(D.$$.fragment),Q=M(),f(N.$$.fragment),R=M(),f(V.$$.fragment),this.h()},l($){t=U($,"DIV",{});var u=d(t);n=U(u,"SPAN",{class:!0});var w=d(n);c(e.$$.fragment,w),s=C(w),c(o.$$.fragment,w),m=C(w),c(_.$$.fragment,w),S=C(w),c(l.$$.fragment,w),W=C(w),c(k.$$.fragment,w),w.forEach(r),J=C(u),b=U(u,"SPAN",{class:!0});var E=d(b);c(A.$$.fragment,E),K=C(E),c(P.$$.fragment,E),O=C(E),c(D.$$.fragment,E),Q=C(E),c(N.$$.fragment,E),R=C(E),c(V.$$.fragment,E),E.forEach(r),u.forEach(r),this.h()},h(){x(n,"class","svelte-1ect03w"),x(b,"class","svelte-1ect03w")},m($,u){B($,t,u),g(t,n),i(e,n,null),g(n,s),i(o,n,null),g(n,m),i(_,n,null),g(n,S),i(l,n,null),g(n,W),i(k,n,null),g(t,J),g(t,b),i(A,b,null),g(b,K),i(P,b,null),g(b,O),i(D,b,null),g(b,Q),i(N,b,null),g(b,R),i(V,b,null),H=!0},p($,[u]){const w={};u&1&&(w.$$scope={dirty:u,ctx:$}),e.$set(w);const E={};u&1&&(E.$$scope={dirty:u,ctx:$}),o.$set(E);const X={};u&1&&(X.$$scope={dirty:u,ctx:$}),_.$set(X);const Y={};u&1&&(Y.$$scope={dirty:u,ctx:$}),l.$set(Y);const Z={};u&1&&(Z.$$scope={dirty:u,ctx:$}),k.$set(Z);const y={};u&1&&(y.$$scope={dirty:u,ctx:$}),A.$set(y);const tt={};u&1&&(tt.$$scope={dirty:u,ctx:$}),P.$set(tt);const et={};u&1&&(et.$$scope={dirty:u,ctx:$}),D.$set(et);const nt={};u&1&&(nt.$$scope={dirty:u,ctx:$}),N.$set(nt);const st={};u&1&&(st.$$scope={dirty:u,ctx:$}),V.$set(st)},i($){H||(p(e.$$.fragment,$),p(o.$$.fragment,$),p(_.$$.fragment,$),p(l.$$.fragment,$),p(k.$$.fragment,$),p(A.$$.fragment,$),p(P.$$.fragment,$),p(D.$$.fragment,$),p(N.$$.fragment,$),p(V.$$.fragment,$),H=!0)},o($){h(e.$$.fragment,$),h(o.$$.fragment,$),h(_.$$.fragment,$),h(l.$$.fragment,$),h(k.$$.fragment,$),h(A.$$.fragment,$),h(P.$$.fragment,$),h(D.$$.fragment,$),h(N.$$.fragment,$),h(V.$$.fragment,$),H=!1},d($){$&&r(t),v(e),v(o),v(_),v(l),v(k),v(A),v(P),v(D),v(N),v(V)}}}class pe extends ot{constructor(t){super(),$t(this,t,null,ie,at,{})}}const he=`<script>
	import Button from '@mui3/button';
	import Icon from '@mui3/icon';
<\/script>
<div>
	<span>
		<Button icon>
			<Icon>
				<svg><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>
			</Icon>
		</Button>
		<Button icon variant="tonal">
			<Icon>
				<svg><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>
			</Icon>
		</Button>
		<Button icon variant="elevated">
			<Icon>
				<svg><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>
			</Icon>
		</Button>
		<Button icon variant="outline">
			<Icon>
				<svg><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>
			</Icon>
		</Button>
		<Button icon variant="text">
			<Icon>
				<svg><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>
			</Icon>
		</Button>
	</span>
	<span>
		<Button disabled icon>
			<Icon>
				<svg><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>
			</Icon>
		</Button>
		<Button disabled icon variant="tonal">
			<Icon>
				<svg><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>
			</Icon>
		</Button>
		<Button disabled icon variant="elevated">
			<Icon>
				<svg><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>
			</Icon>
		</Button>
		<Button disabled icon variant="outline">
			<Icon>
				<svg><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>
			</Icon>
		</Button>
		<Button disabled icon variant="text">
			<Icon>
				<svg><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>
			</Icon>
		</Button>
	</span>

</div>

<style>
	span {
		display: flex;
		flex-wrap: wrap;
		gap: 16px;
		padding: 8px 0;
	}
</style>
`;function ve(a){let t;return{c(){t=q("Button")},l(n){t=F(n,"Button")},m(n,e){B(n,t,e)},d(n){n&&r(t)}}}function ge(a){let t;return{c(){t=q("Button")},l(n){t=F(n,"Button")},m(n,e){B(n,t,e)},d(n){n&&r(t)}}}function me(a){let t,n,e,s,o,m;return n=new L({props:{disableElevation:!0,color:"black",background:"coral",$$slots:{default:[ve]},$$scope:{ctx:a}}}),s=new L({props:{$$slots:{default:[ge]},$$scope:{ctx:a}}}),{c(){t=T("div"),f(n.$$.fragment),e=M(),o=T("div"),f(s.$$.fragment),this.h()},l(_){t=U(_,"DIV",{});var S=d(t);c(n.$$.fragment,S),e=C(S),o=U(S,"DIV",{style:!0});var l=d(o);c(s.$$.fragment,l),S.forEach(r),this.h()},h(){ut(o,"display","contents"),ut(o,"--md-button-color","orange"),ut(o,"--md-button-background","dodgerblue")},m(_,S){B(_,t,S),i(n,t,null),g(t,e),g(t,o),i(s,o,null),m=!0},p(_,[S]){const l={};S&1&&(l.$$scope={dirty:S,ctx:_}),n.$set(l);const W={};S&1&&(W.$$scope={dirty:S,ctx:_}),s.$set(W)},i(_){m||(p(n.$$.fragment,_),p(s.$$.fragment,_),m=!0)},o(_){h(n.$$.fragment,_),h(s.$$.fragment,_),m=!1},d(_){_&&r(t),v(n),v(s)}}}class de extends ot{constructor(t){super(),$t(this,t,null,me,at,{})}}const _e=`<script>
	import Button from '@mui3/button';
<\/script>

<div>
    <Button disableElevation color="black" background="coral">
        Button
    </Button>

    <Button --md-button-color="orange" --md-button-background="dodgerblue">
        Button
    </Button>
</div>

<style>
</style>
`,Be={title:"Simple",Component:bt,code:wt},be={title:"With Icon",Component:Kt,code:Ot},we={title:"Icon",Component:pe,code:he},Ee={title:"Customization",Component:de,code:_e};function Ie(a){let t,n,e,s,o,m,_,S;return t=new rt({props:{data:Be,repl:"https://svelte.dev/repl/1c6f252678d441bb947d9b861bd52cbb?version=4.0.1"}}),e=new rt({props:{data:be}}),o=new rt({props:{data:we}}),_=new rt({props:{data:Ee}}),{c(){f(t.$$.fragment),n=M(),f(e.$$.fragment),s=M(),f(o.$$.fragment),m=M(),f(_.$$.fragment)},l(l){c(t.$$.fragment,l),n=C(l),c(e.$$.fragment,l),s=C(l),c(o.$$.fragment,l),m=C(l),c(_.$$.fragment,l)},m(l,W){i(t,l,W),B(l,n,W),i(e,l,W),B(l,s,W),i(o,l,W),B(l,m,W),i(_,l,W),S=!0},p:j,i(l){S||(p(t.$$.fragment,l),p(e.$$.fragment,l),p(o.$$.fragment,l),p(_.$$.fragment,l),S=!0)},o(l){h(t.$$.fragment,l),h(e.$$.fragment,l),h(o.$$.fragment,l),h(_.$$.fragment,l),S=!1},d(l){v(t,l),l&&r(n),v(e,l),l&&r(s),v(o,l),l&&r(m),v(_,l)}}}function ze(a){let t,n;return t=new lt({props:{title:"Buttons",link:"https://m3.material.io/components/buttons/overview",description:"Buttons help people take action, such as sending an email, sharing a document, or liking a comment",$$slots:{default:[Ie]},$$scope:{ctx:a}}}),{c(){f(t.$$.fragment)},l(e){c(t.$$.fragment,e)},m(e,s){i(t,e,s),n=!0},p(e,[s]){const o={};s&1&&(o.$$scope={dirty:s,ctx:e}),t.$set(o)},i(e){n||(p(t.$$.fragment,e),n=!0)},o(e){h(t.$$.fragment,e),n=!1},d(e){v(t,e)}}}class ke extends ot{constructor(t){super(),$t(this,t,null,ze,at,{})}}export{ke as component};
