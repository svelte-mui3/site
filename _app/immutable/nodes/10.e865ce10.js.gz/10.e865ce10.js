import{S as e,i as t,s as n}from"../chunks/index.c17a76e4.js";class l extends e{constructor(s){super(),t(this,s,null,null,n,{})}}export{l as component};
