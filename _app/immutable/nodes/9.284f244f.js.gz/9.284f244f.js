import{S as e,i as t,s as n}from"../chunks/index.b9a67496.js";class l extends e{constructor(s){super(),t(this,s,null,null,n,{})}}export{l as component};
