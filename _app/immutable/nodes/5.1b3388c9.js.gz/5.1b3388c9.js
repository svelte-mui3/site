import{S as B,i as D,s as z,_ as j,y as v,z as C,A as x,a0 as Se,a5 as Ve,g,d as k,B as y,a6 as W,a7 as Oe,W as p,G as Be,a as N,C as q,c as E,D as L,m as V,h as d,n as m,b as $,E as b,H as De,I as ze,J as He,k as w,l as I,F as A,q as F,r as G,u as J,P as O,a8 as H,a9 as M}from"../chunks/index.c17a76e4.js";import{C as R}from"../chunks/code.eed80d1b.js";import{E as Ae}from"../chunks/example.b3b9ea27.js";import{B as Re}from"../chunks/button.9d5c653e.js";function qe(t){let e,n,a,c,o;const s=t[4].default,u=Be(s,t,t[48],null);return{c(){u&&u.c(),e=N(),n=q("svg"),a=q("path"),c=q("path"),this.h()},l(h){u&&u.l(h),e=E(h),n=L(h,"svg",{class:!0,viewBox:!0});var i=V(n);a=L(i,"path",{class:!0,d:!0}),V(a).forEach(d),c=L(i,"path",{class:!0,d:!0}),V(c).forEach(d),i.forEach(d),this.h()},h(){m(a,"class","checked svelte-1dw5bnm"),m(a,"d","M19 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.11 0 2-.9 2-2V5c0-1.1-.89-2-2-2zm-9 14l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"),m(c,"class","empty svelte-1dw5bnm"),m(c,"d","M19 5v14H5V5h14m0-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z"),m(n,"class","md-icon md-checkbox svelte-1dw5bnm"),m(n,"viewBox","0 0 24 24")},m(h,i){u&&u.m(h,i),$(h,e,i),$(h,n,i),b(n,a),b(n,c),o=!0},p(h,i){u&&u.p&&(!o||i[1]&131072)&&De(u,s,h,h[48],o?He(s,h[48],i,null):ze(h[48]),null)},i(h){o||(g(u,h),o=!0)},o(h){k(u,h),o=!1},d(h){u&&u.d(h),h&&d(e),h&&d(n)}}}function Le(t){let e,n;const a=[{ripple:t[0]},{color:t[1]},{background:t[2]},{icon:!0},{tag:"label"},{variant:"text"},t[3]];let c={$$slots:{default:[qe]},$$scope:{ctx:t}};for(let o=0;o<a.length;o+=1)c=j(c,a[o]);return e=new Re({props:c}),e.$on("auxclick",t[5]),e.$on("click",t[6]),e.$on("contextmenu",t[7]),e.$on("dblclick",t[8]),e.$on("drag",t[9]),e.$on("dragend",t[10]),e.$on("dragenter",t[11]),e.$on("dragexit",t[12]),e.$on("dragleave",t[13]),e.$on("dragover",t[14]),e.$on("dragstart",t[15]),e.$on("drop",t[16]),e.$on("mousedown",t[17]),e.$on("mouseenter",t[18]),e.$on("mouseleave",t[19]),e.$on("mousemove",t[20]),e.$on("mouseout",t[21]),e.$on("mouseover",t[22]),e.$on("mouseup",t[23]),e.$on("focus",t[24]),e.$on("focusin",t[25]),e.$on("focusout",t[26]),e.$on("blur",t[27]),e.$on("keydown",t[28]),e.$on("keypress",t[29]),e.$on("keyup",t[30]),e.$on("gotpointercapture",t[31]),e.$on("pointercancel",t[32]),e.$on("pointerdown",t[33]),e.$on("pointerenter",t[34]),e.$on("pointerleave",t[35]),e.$on("pointermove",t[36]),e.$on("pointerout",t[37]),e.$on("pointerover",t[38]),e.$on("pointerup",t[39]),e.$on("lostpointercapture",t[40]),e.$on("animationstart",t[41]),e.$on("animationend",t[42]),e.$on("animationiteration",t[43]),e.$on("transitionstart",t[44]),e.$on("transitionrun",t[45]),e.$on("transitionend",t[46]),e.$on("transitioncancel",t[47]),{c(){v(e.$$.fragment)},l(o){C(e.$$.fragment,o)},m(o,s){x(e,o,s),n=!0},p(o,s){const u=s[0]&15?Se(a,[s[0]&1&&{ripple:o[0]},s[0]&2&&{color:o[1]},s[0]&4&&{background:o[2]},a[3],a[4],a[5],s[0]&8&&Ve(o[3])]):{};s[1]&131072&&(u.$$scope={dirty:s,ctx:o}),e.$set(u)},i(o){n||(g(e.$$.fragment,o),n=!0)},o(o){k(e.$$.fragment,o),n=!1},d(o){y(e,o)}}}function Me(t,e,n){const a=["ripple","color","background"];let c=W(e,a),{$$slots:o={},$$scope:s}=e,{ripple:u=null}=e,{color:h=null}=e,{background:i=null}=e;function f(l){p.call(this,t,l)}function r(l){p.call(this,t,l)}function _(l){p.call(this,t,l)}function P(l){p.call(this,t,l)}function U(l){p.call(this,t,l)}function S(l){p.call(this,t,l)}function K(l){p.call(this,t,l)}function Q(l){p.call(this,t,l)}function X(l){p.call(this,t,l)}function Y(l){p.call(this,t,l)}function Z(l){p.call(this,t,l)}function ee(l){p.call(this,t,l)}function te(l){p.call(this,t,l)}function ne(l){p.call(this,t,l)}function oe(l){p.call(this,t,l)}function ae(l){p.call(this,t,l)}function le(l){p.call(this,t,l)}function ce(l){p.call(this,t,l)}function se(l){p.call(this,t,l)}function ie(l){p.call(this,t,l)}function re(l){p.call(this,t,l)}function ue(l){p.call(this,t,l)}function he(l){p.call(this,t,l)}function pe(l){p.call(this,t,l)}function fe(l){p.call(this,t,l)}function _e(l){p.call(this,t,l)}function de(l){p.call(this,t,l)}function me(l){p.call(this,t,l)}function $e(l){p.call(this,t,l)}function ge(l){p.call(this,t,l)}function ke(l){p.call(this,t,l)}function be(l){p.call(this,t,l)}function ve(l){p.call(this,t,l)}function Ce(l){p.call(this,t,l)}function xe(l){p.call(this,t,l)}function ye(l){p.call(this,t,l)}function we(l){p.call(this,t,l)}function Ie(l){p.call(this,t,l)}function Pe(l){p.call(this,t,l)}function Ne(l){p.call(this,t,l)}function Ee(l){p.call(this,t,l)}function Te(l){p.call(this,t,l)}function Ue(l){p.call(this,t,l)}return t.$$set=l=>{e=j(j({},e),Oe(l)),n(3,c=W(e,a)),"ripple"in l&&n(0,u=l.ripple),"color"in l&&n(1,h=l.color),"background"in l&&n(2,i=l.background),"$$scope"in l&&n(48,s=l.$$scope)},[u,h,i,c,o,f,r,_,P,U,S,K,Q,X,Y,Z,ee,te,ne,oe,ae,le,ce,se,ie,re,ue,he,pe,fe,_e,de,me,$e,ge,ke,be,ve,Ce,xe,ye,we,Ie,Pe,Ne,Ee,Te,Ue,s]}class T extends B{constructor(e){super(),D(this,e,Me,Le,z,{ripple:0,color:1,background:2},null,[-1,-1])}}function je(t){let e;return{c(){e=w("input"),this.h()},l(n){e=I(n,"INPUT",{type:!0}),this.h()},h(){m(e,"type","checkbox")},m(n,a){$(n,e,a)},p:A,d(n){n&&d(e)}}}function Fe(t){let e;return{c(){e=w("input"),this.h()},l(n){e=I(n,"INPUT",{type:!0}),this.h()},h(){m(e,"type","checkbox"),e.checked=!0},m(n,a){$(n,e,a)},p:A,d(n){n&&d(e)}}}function Ge(t){let e;return{c(){e=w("input"),this.h()},l(n){e=I(n,"INPUT",{type:!0}),this.h()},h(){m(e,"type","checkbox"),e.disabled=!0},m(n,a){$(n,e,a)},p:A,d(n){n&&d(e)}}}function Je(t){let e;return{c(){e=w("input"),this.h()},l(n){e=I(n,"INPUT",{type:!0}),this.h()},h(){m(e,"type","checkbox"),e.disabled=!0,e.checked=!0},m(n,a){$(n,e,a)},p:A,d(n){n&&d(e)}}}function We(t){let e,n,a,c,o,s,u,h,i;return n=new T({props:{$$slots:{default:[je]},$$scope:{ctx:t}}}),c=new T({props:{$$slots:{default:[Fe]},$$scope:{ctx:t}}}),s=new T({props:{$$slots:{default:[Ge]},$$scope:{ctx:t}}}),h=new T({props:{$$slots:{default:[Je]},$$scope:{ctx:t}}}),{c(){e=w("div"),v(n.$$.fragment),a=N(),v(c.$$.fragment),o=N(),v(s.$$.fragment),u=N(),v(h.$$.fragment),this.h()},l(f){e=I(f,"DIV",{class:!0});var r=V(e);C(n.$$.fragment,r),a=E(r),C(c.$$.fragment,r),o=E(r),C(s.$$.fragment,r),u=E(r),C(h.$$.fragment,r),r.forEach(d),this.h()},h(){m(e,"class","svelte-1lcl7k")},m(f,r){$(f,e,r),x(n,e,null),b(e,a),x(c,e,null),b(e,o),x(s,e,null),b(e,u),x(h,e,null),i=!0},p(f,[r]){const _={};r&1&&(_.$$scope={dirty:r,ctx:f}),n.$set(_);const P={};r&1&&(P.$$scope={dirty:r,ctx:f}),c.$set(P);const U={};r&1&&(U.$$scope={dirty:r,ctx:f}),s.$set(U);const S={};r&1&&(S.$$scope={dirty:r,ctx:f}),h.$set(S)},i(f){i||(g(n.$$.fragment,f),g(c.$$.fragment,f),g(s.$$.fragment,f),g(h.$$.fragment,f),i=!0)},o(f){k(n.$$.fragment,f),k(c.$$.fragment,f),k(s.$$.fragment,f),k(h.$$.fragment,f),i=!1},d(f){f&&d(e),y(n),y(c),y(s),y(h)}}}class Ke extends B{constructor(e){super(),D(this,e,null,We,z,{})}}const Qe=`<script>
	import Checkbox from '@mui3/checkbox';
<\/script>

<div>
	<Checkbox>
		<input type="checkbox" />
	</Checkbox>

	<Checkbox>
		<input type="checkbox" checked />
	</Checkbox>

	<Checkbox>
		<input type="checkbox" disabled />
	</Checkbox>

	<Checkbox>
		<input type="checkbox" disabled checked />
	</Checkbox>
</div>

<style>
	div {
		display: flex;
		gap: 16px;
	}
</style>
`;function Xe(t){let e,n,a;return{c(){e=w("input"),this.h()},l(c){e=I(c,"INPUT",{type:!0}),this.h()},h(){m(e,"type","checkbox")},m(c,o){$(c,e,o),e.checked=t[0],n||(a=O(e,"change",t[1]),n=!0)},p(c,o){o&1&&(e.checked=c[0])},d(c){c&&d(e),n=!1,a()}}}function Ye(t){let e,n,a,c,o;return n=new T({props:{$$slots:{default:[Xe]},$$scope:{ctx:t}}}),{c(){e=w("div"),v(n.$$.fragment),a=N(),c=F(t[0]),this.h()},l(s){e=I(s,"DIV",{class:!0});var u=V(e);C(n.$$.fragment,u),a=E(u),c=G(u,t[0]),u.forEach(d),this.h()},h(){m(e,"class","svelte-1d4fmra")},m(s,u){$(s,e,u),x(n,e,null),b(e,a),b(e,c),o=!0},p(s,[u]){const h={};u&5&&(h.$$scope={dirty:u,ctx:s}),n.$set(h),(!o||u&1)&&J(c,s[0])},i(s){o||(g(n.$$.fragment,s),o=!0)},o(s){k(n.$$.fragment,s),o=!1},d(s){s&&d(e),y(n)}}}function Ze(t,e,n){let a=!1;function c(){a=this.checked,n(0,a)}return[a,c]}class et extends B{constructor(e){super(),D(this,e,Ze,Ye,z,{})}}const tt=`<script>
	import Checkbox from '@mui3/checkbox';

	let checked = false;
<\/script>

<div>
	<Checkbox>
		<input type="checkbox" bind:checked />
	</Checkbox>

	{checked}
</div>

<style>
	div {
		display: flex;
		width: 120px;
		gap: 16px;
		align-items: center;
	}
</style>
`;function nt(t){let e,n,a,c;return n=H(t[2][0]),{c(){e=w("input"),this.h()},l(o){e=I(o,"INPUT",{type:!0}),this.h()},h(){m(e,"type","checkbox"),e.__value=1,e.value=e.__value,n.p(e)},m(o,s){$(o,e,s),e.checked=~(t[0]||[]).indexOf(e.__value),a||(c=O(e,"change",t[1]),a=!0)},p(o,s){s&1&&(e.checked=~(o[0]||[]).indexOf(e.__value))},d(o){o&&d(e),n.r(),a=!1,c()}}}function ot(t){let e,n,a,c;return n=H(t[2][0]),{c(){e=w("input"),this.h()},l(o){e=I(o,"INPUT",{type:!0}),this.h()},h(){m(e,"type","checkbox"),e.__value=2,e.value=e.__value,n.p(e)},m(o,s){$(o,e,s),e.checked=~(t[0]||[]).indexOf(e.__value),a||(c=O(e,"change",t[3]),a=!0)},p(o,s){s&1&&(e.checked=~(o[0]||[]).indexOf(e.__value))},d(o){o&&d(e),n.r(),a=!1,c()}}}function at(t){let e,n,a,c;return n=H(t[2][0]),{c(){e=w("input"),this.h()},l(o){e=I(o,"INPUT",{type:!0}),this.h()},h(){m(e,"type","checkbox"),e.__value=3,e.value=e.__value,n.p(e)},m(o,s){$(o,e,s),e.checked=~(t[0]||[]).indexOf(e.__value),a||(c=O(e,"change",t[4]),a=!0)},p(o,s){s&1&&(e.checked=~(o[0]||[]).indexOf(e.__value))},d(o){o&&d(e),n.r(),a=!1,c()}}}function lt(t){let e,n,a,c,o,s,u,h,i,f;return n=new T({props:{$$slots:{default:[nt]},$$scope:{ctx:t}}}),c=new T({props:{$$slots:{default:[ot]},$$scope:{ctx:t}}}),s=new T({props:{$$slots:{default:[at]},$$scope:{ctx:t}}}),{c(){e=w("div"),v(n.$$.fragment),a=N(),v(c.$$.fragment),o=N(),v(s.$$.fragment),u=N(),h=w("span"),i=F(t[0]),this.h()},l(r){e=I(r,"DIV",{class:!0});var _=V(e);C(n.$$.fragment,_),a=E(_),C(c.$$.fragment,_),o=E(_),C(s.$$.fragment,_),u=E(_),h=I(_,"SPAN",{});var P=V(h);i=G(P,t[0]),P.forEach(d),_.forEach(d),this.h()},h(){m(e,"class","svelte-1af4v3u")},m(r,_){$(r,e,_),x(n,e,null),b(e,a),x(c,e,null),b(e,o),x(s,e,null),b(e,u),b(e,h),b(h,i),f=!0},p(r,[_]){const P={};_&33&&(P.$$scope={dirty:_,ctx:r}),n.$set(P);const U={};_&33&&(U.$$scope={dirty:_,ctx:r}),c.$set(U);const S={};_&33&&(S.$$scope={dirty:_,ctx:r}),s.$set(S),(!f||_&1)&&J(i,r[0])},i(r){f||(g(n.$$.fragment,r),g(c.$$.fragment,r),g(s.$$.fragment,r),f=!0)},o(r){k(n.$$.fragment,r),k(c.$$.fragment,r),k(s.$$.fragment,r),f=!1},d(r){r&&d(e),y(n),y(c),y(s)}}}function ct(t,e,n){let a=[1];const c=[[]];function o(){a=M(c[0],this.__value,this.checked),n(0,a)}function s(){a=M(c[0],this.__value,this.checked),n(0,a)}function u(){a=M(c[0],this.__value,this.checked),n(0,a)}return[a,o,c,s,u]}class st extends B{constructor(e){super(),D(this,e,ct,lt,z,{})}}const it=`<script>
	import Checkbox from '@mui3/checkbox';

	let group = [1];
<\/script>

<div>
	<Checkbox>
		<input type="checkbox" bind:group value={1} />
	</Checkbox>

	<Checkbox>
		<input type="checkbox" bind:group value={2}/>
	</Checkbox>

	<Checkbox>
		<input type="checkbox" bind:group value={3} />
	</Checkbox>

	<span>{group}</span>
</div>

<style>
	div {
		display: flex;
		min-width: 240px;
		align-items: center;
		gap: 16px;
	}
</style>
`;function rt(t){let e,n,a,c;return n=H(t[2][0]),{c(){e=w("input"),this.h()},l(o){e=I(o,"INPUT",{type:!0}),this.h()},h(){m(e,"type","radio"),e.__value=1,e.value=e.__value,n.p(e)},m(o,s){$(o,e,s),e.checked=e.__value===t[0],a||(c=O(e,"change",t[1]),a=!0)},p(o,s){s&1&&(e.checked=e.__value===o[0])},d(o){o&&d(e),n.r(),a=!1,c()}}}function ut(t){let e,n,a,c;return n=H(t[2][0]),{c(){e=w("input"),this.h()},l(o){e=I(o,"INPUT",{type:!0}),this.h()},h(){m(e,"type","radio"),e.__value=2,e.value=e.__value,n.p(e)},m(o,s){$(o,e,s),e.checked=e.__value===t[0],a||(c=O(e,"change",t[3]),a=!0)},p(o,s){s&1&&(e.checked=e.__value===o[0])},d(o){o&&d(e),n.r(),a=!1,c()}}}function ht(t){let e,n,a,c;return n=H(t[2][0]),{c(){e=w("input"),this.h()},l(o){e=I(o,"INPUT",{type:!0}),this.h()},h(){m(e,"type","radio"),e.__value=3,e.value=e.__value,n.p(e)},m(o,s){$(o,e,s),e.checked=e.__value===t[0],a||(c=O(e,"change",t[4]),a=!0)},p(o,s){s&1&&(e.checked=e.__value===o[0])},d(o){o&&d(e),n.r(),a=!1,c()}}}function pt(t){let e,n,a,c,o,s,u,h,i,f;return n=new T({props:{$$slots:{default:[rt]},$$scope:{ctx:t}}}),c=new T({props:{$$slots:{default:[ut]},$$scope:{ctx:t}}}),s=new T({props:{$$slots:{default:[ht]},$$scope:{ctx:t}}}),{c(){e=w("div"),v(n.$$.fragment),a=N(),v(c.$$.fragment),o=N(),v(s.$$.fragment),u=N(),h=w("span"),i=F(t[0]),this.h()},l(r){e=I(r,"DIV",{class:!0});var _=V(e);C(n.$$.fragment,_),a=E(_),C(c.$$.fragment,_),o=E(_),C(s.$$.fragment,_),u=E(_),h=I(_,"SPAN",{});var P=V(h);i=G(P,t[0]),P.forEach(d),_.forEach(d),this.h()},h(){m(e,"class","svelte-1af4v3u")},m(r,_){$(r,e,_),x(n,e,null),b(e,a),x(c,e,null),b(e,o),x(s,e,null),b(e,u),b(e,h),b(h,i),f=!0},p(r,[_]){const P={};_&33&&(P.$$scope={dirty:_,ctx:r}),n.$set(P);const U={};_&33&&(U.$$scope={dirty:_,ctx:r}),c.$set(U);const S={};_&33&&(S.$$scope={dirty:_,ctx:r}),s.$set(S),(!f||_&1)&&J(i,r[0])},i(r){f||(g(n.$$.fragment,r),g(c.$$.fragment,r),g(s.$$.fragment,r),f=!0)},o(r){k(n.$$.fragment,r),k(c.$$.fragment,r),k(s.$$.fragment,r),f=!1},d(r){r&&d(e),y(n),y(c),y(s)}}}function ft(t,e,n){let a=1;const c=[[]];function o(){a=this.__value,n(0,a)}function s(){a=this.__value,n(0,a)}function u(){a=this.__value,n(0,a)}return[a,o,c,s,u]}class _t extends B{constructor(e){super(),D(this,e,ft,pt,z,{})}}const dt=`<script>
	import Checkbox from '@mui3/checkbox';

	let group = 1;
<\/script>

<div>
	<Checkbox>
		<input type="radio" bind:group value={1} />
	</Checkbox>

	<Checkbox>
		<input type="radio" bind:group value={2}/>
	</Checkbox>

	<Checkbox>
		<input type="radio" bind:group value={3} />
	</Checkbox>

	<span>{group}</span>
</div>

<style>
	div {
		display: flex;
		min-width: 240px;
		align-items: center;
		gap: 16px;
	}
</style>
`,mt={title:"Simple",Component:Ke,code:Qe},$t={title:"Single",Component:et,code:tt},gt={title:"Checkbox group",Component:st,code:it},kt={title:"Radio group",Component:_t,code:dt};function bt(t){let e,n,a,c,o,s,u,h;return e=new R({props:{data:mt}}),a=new R({props:{data:$t}}),o=new R({props:{data:gt}}),u=new R({props:{data:kt}}),{c(){v(e.$$.fragment),n=N(),v(a.$$.fragment),c=N(),v(o.$$.fragment),s=N(),v(u.$$.fragment)},l(i){C(e.$$.fragment,i),n=E(i),C(a.$$.fragment,i),c=E(i),C(o.$$.fragment,i),s=E(i),C(u.$$.fragment,i)},m(i,f){x(e,i,f),$(i,n,f),x(a,i,f),$(i,c,f),x(o,i,f),$(i,s,f),x(u,i,f),h=!0},p:A,i(i){h||(g(e.$$.fragment,i),g(a.$$.fragment,i),g(o.$$.fragment,i),g(u.$$.fragment,i),h=!0)},o(i){k(e.$$.fragment,i),k(a.$$.fragment,i),k(o.$$.fragment,i),k(u.$$.fragment,i),h=!1},d(i){y(e,i),i&&d(n),y(a,i),i&&d(c),y(o,i),i&&d(s),y(u,i)}}}function vt(t){let e,n;return e=new Ae({props:{title:"Checkbox",description:"Checkboxes allow users to select one or more items from a set. Checkboxes can turn an option on or off.",link:"https://m3.material.io/components/checkbox/overview",$$slots:{default:[bt]},$$scope:{ctx:t}}}),{c(){v(e.$$.fragment)},l(a){C(e.$$.fragment,a)},m(a,c){x(e,a,c),n=!0},p(a,[c]){const o={};c&1&&(o.$$scope={dirty:c,ctx:a}),e.$set(o)},i(a){n||(g(e.$$.fragment,a),n=!0)},o(a){k(e.$$.fragment,a),n=!1},d(a){y(e,a)}}}class It extends B{constructor(e){super(),D(this,e,null,vt,z,{})}}export{It as component};
